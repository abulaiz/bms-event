	var dc = $(".selectize-input");
	for(var i=0; i<dc.length; i++){
	    dc[i].style.backgroundImage = "linear-gradient(to bottom, #fefefe, white)";
	    dc[i].style.padding = "11px";
	}