<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->date('started_date');
            $table->date('ended_date');
            $table->string('place');
            $table->text('description');
            $table->string('agency');
            $table->char('type', 1); // 1 : Public, 2 : Private / InHouse
            $table->string('flag')->nullable();
            $table->date('last_attendance')->nullable();
            $table->smallInteger('attendance_count')->default(0); // Jumlah Hitungan Kehadiran
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events');
    }
}
