<div class="modal fade text-left" id="generate-nametag" tabindex="-1" role="dialog" aria-labelledby="proses-caption" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <label class="modal-title text-text-bold-600" id="proses-caption">-</label>
      </div>
      <div class="modal-body">
        <div class="loader-wrapper">
          <div class="loader-container">
            <div class="ball-spin-fade-loader loader-blue">
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
          </div>
        </div>
        <p style="text-align: center;" id="fetch-init">Mengambil data peserta ...</p>
        <p style="text-align: center;" id="fetch-progress">Memproses data ke <span id="generate-nametag-caption-from">-</span> dari <span id="generate-nametag-caption-to">-</span></p>
      </div>
    </div>
  </div>
</div>