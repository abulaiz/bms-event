 <button type="button" class="btn btn-outline-primary dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
<div class="dropdown-menu" x-placement="bottom-start">
	<a onclick="_detail(this)" class="dropdown-item">Detail</a>	
    <a onclick="_edit(this)" class="dropdown-item">Edit</a>    
    <div class="dropdown-divider"></div>
    <a onclick="_delete(this)" class="dropdown-item">Hapus</a>
</div>