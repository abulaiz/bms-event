<button type="button" class="btn btn-outline-primary dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
<div class="dropdown-menu" x-placement="bottom-start">   
    <a onclick="generate_id(this)" class="dropdown-item">Lihat ID Card</a>
    <a onclick="send_certificate(this)" class="dropdown-item">Kirim E-Serifikat</a>
    <div class="dropdown-divider"></div>
    <a onclick="_detail(this)" class="dropdown-item">Detail Data</a>
    <a onclick="_delete(this)" class="dropdown-item">Hapus Data</a>
</div>