@extends('_admin._templates.master')
@section('title', 'Laporan | BMS')