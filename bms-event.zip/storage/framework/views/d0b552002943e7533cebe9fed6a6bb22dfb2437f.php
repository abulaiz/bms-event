<img src="<?php echo e(URL::asset('img/master_certificate.jpg')); ?>" style="height: 793px;">

<p style="position: absolute; top: 140px; left: 750px; font-size: 20px; color: yellow; font-weight: bold;">REG : BMS-GBL/022-0003798/XII/2019</p>

<p style="position: absolute; top: 340px; left: 80px; font-size: 45px; max-width: 800px; color: #e48d2a">Imron Abu Laiz ST MMPD</p>

<p style="position: absolute; top: 440px; left: 80px; font-size: 32px; max-width: 800px; font-style: italic; font-weight: bold;">INTERNATIONAL CONFERENCE OF HIME HIME</p>

<p style="position: absolute; top: 510px; left: 80px; max-width: 1000px; font-size: 23px;">Yang diselenggarakan oleh Bangkit Mandiri Sejahtera (BMS) Global Consultant, 28 Desember 2019</p>

<style type="text/css">
html{
	width: 100%;
	height: 100%; 
	padding: 0;
	margin: 0;
}	
p{
	opacity: 0.7;
}
</style>