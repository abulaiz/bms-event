<img src="<?php echo e(URL::asset('img/logo_bms.png')); ?>" style="height: 160px; margin-top: 10px;">

<div style="text-align: center; font-weight: bold; max-width: 650px; position: absolute; top: 1px; left: 200px;">
<p style="font-size: 30px; font-family: 'latobold';">TRAINING PELATIHAN MANAJEMEN 2020 PT.BEE TECHNOLOGY INDONESIA</p>
<small style="font-size: 20px;">BANDUNG 12-14 November 2020</small>	
</div>

<div style="position: absolute; top: 240px; left: 0px; text-align: center; ">
	<h1 style="font-size: 68px;">ABDUL LESTALUHU</h1>	
</div>

<div style="text-align: center; font-weight: bold; position: absolute; top: 500px; left: 0px;">
<p style="font-size: 30px; font-family: 'latobold';">BMS GLOBAL TRAINING & CONSULTING</p>
<small style="font-size: 20px;">www.bmsglobal.co.id</small>	
</div>