<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet"> 

<?php 
	$i = 1;
?>

<style>
	body{
		font-family: "Roboto", Arial, Helvetica, sans-serif;	
		font-size: 12px;
	}
	#customers {
	  border-collapse: collapse;
	  width: 100%;
	}

	#customers td, #customers th {
	  border: 1px solid #ddd;
	  padding: 8px;
	}

	#customers tr:nth-child(even){background-color: #f2f2f2;}

	#customers tr:hover {background-color: #ddd;}

	#customers th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #31adbc;
	  color: white;
	}
</style>
</head>
<body>
<h2 style="text-align: center;">Laporan Peserta Acara <?php echo e($event_name); ?></h2>

<table id="customers">
	<thead>
	  <tr>
	    <th>No</th>
	    <th>Nama Lengkap</th>
	    <th>No Tlp</th>
	    <th>Email</th>
	    <th>Instansi</th>
	    <th>Kehadiran</th>
	  </tr>	
	</thead>	
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="text-align: center;"><?php echo e($i++); ?></td>
				<td><?php echo e($item->full_name); ?></td>
				<td><?php echo e($item->phone); ?></td>
				<td><?php echo e($item->email); ?></td>
				<td><?php echo e($item->job->agency); ?></td>
				<td style="text-align: center;"><?php echo e($item->attendances()->count() > 0 ? "Hadir" : "Tidak Hadir"); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

</body>